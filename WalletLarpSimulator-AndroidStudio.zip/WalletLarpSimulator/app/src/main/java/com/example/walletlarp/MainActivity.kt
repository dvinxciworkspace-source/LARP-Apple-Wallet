package com.example.walletlarp

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class WalletCard(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subtitle: String,
    val number: String,
    val image: String = "",
    val tint: Long = 0xFF263A56,
    val kind: String = "Membership"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WalletApp() }
    }
}

private val ink = Color(0xFF08090D)
private val panel = Color(0xFF17191F)
private val muted = Color(0xFF9A9DA7)
private val accent = Color(0xFF4D9CFF)

@Composable
fun WalletApp() {
    val context = LocalContext.current
    var cards by remember { mutableStateOf(loadCards(context)) }
    var selected by remember { mutableStateOf<WalletCard?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    fun persist(next: List<WalletCard>) {
        cards = next
        saveCards(context, next)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = ink, surface = panel, primary = accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = ink) {
            AnimatedContent(targetState = Triple(selected, showEditor, cards), label = "screen") { state ->
                when {
                    state.second -> CardEditor(
                        initial = state.first,
                        onCancel = { showEditor = false },
                        onSave = { card ->
                            val updated = if (state.first == null) state.third + card
                                else state.third.map { if (it.id == card.id) card else it }
                            persist(updated); selected = null; showEditor = false
                        }
                    )
                    state.first != null -> CardDetail(
                        card = state.first!!,
                        onBack = { selected = null },
                        onEdit = { showEditor = true },
                        onDelete = {
                            persist(state.third.filterNot { it.id == state.first!!.id })
                            selected = null
                        }
                    )
                    else -> HomeScreen(
                        cards = state.third,
                        onAdd = { selected = null; showEditor = true },
                        onOpen = { selected = it }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(cards: List<WalletCard>, onAdd: () -> Unit, onOpen: (WalletCard) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Wallet", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("LARP SIMULATOR", fontSize = 10.sp, letterSpacing = 2.sp, color = muted, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onAdd, modifier = Modifier.background(Color(0xFF252832), CircleShape)) {
                Icon(Icons.Default.Add, null, tint = Color.White)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Your cards", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("${cards.size} ITEMS", fontSize = 10.sp, color = muted, letterSpacing = 1.4.sp)
        }
        if (cards.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CreditCard, null, tint = Color(0xFF555A66), modifier = Modifier.size(54.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("No cards yet", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Add a fictional pass to get started.", color = muted, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add a card") }
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.weight(1f)) {
                items(cards, key = { it.id }) { card ->
                    WalletPass(card, Modifier.fillMaxWidth().clickable { onOpen(card) })
                }
                item {
                    OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add another card")
                    }
                }
            }
        }
        Disclaimer()
    }
}

@Composable
fun WalletPass(card: WalletCard, modifier: Modifier = Modifier, large: Boolean = false) {
    val uri = remember(card.image) { runCatching { Uri.parse(card.image) }.getOrNull() }
    Box(modifier.height(if (large) 235.dp else 188.dp).clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(listOf(Color(card.tint), Color(card.tint).copy(alpha = .62f), Color(0xFF10131B))))
    ) {
        if (uri != null && card.image.isNotBlank()) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_gallery),
                contentDescription = null, modifier = Modifier.size(0.dp)
            )
            ImageFromUri(uri, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .30f)))
        }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = .18f)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Wallet, null, tint = Color.White, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(card.title, fontWeight = FontWeight.Bold, fontSize = if (large) 20.sp else 17.sp, color = Color.White)
                    Text(card.subtitle, color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                Text(card.kind.uppercase(), color = Color.White.copy(alpha = .8f), fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Column {
                Text(card.number, fontSize = if (large) 20.sp else 17.sp, letterSpacing = 2.sp,
                    fontWeight = FontWeight.Medium, color = Color.White)
                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("LARP • FICTIONAL PASS", fontSize = 8.sp, letterSpacing = 1.3.sp,
                        color = Color.White.copy(alpha = .75f), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("SIMULATOR", fontSize = 8.sp, letterSpacing = 1.2.sp,
                        color = Color.White.copy(alpha = .85f), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ImageFromUri(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(uri) {
        bitmap = runCatching {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                val source = android.graphics.ImageDecoder.createSource(context.contentResolver, uri)
                android.graphics.ImageDecoder.decodeBitmap(source)
            } else {
                @Suppress("DEPRECATION")
                android.provider.MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
            }
        }.getOrNull()
    }
    bitmap?.let { Image(it.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop) }
}

@Composable
fun CardDetail(card: WalletCard, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
        TopBar("Pass details", onBack)
        Spacer(Modifier.height(22.dp))
        WalletPass(card, Modifier.fillMaxWidth(), large = true)
        Spacer(Modifier.height(24.dp))
        Text("PASS INFORMATION", color = muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        InfoRow("Name", card.title); InfoRow("Description", card.subtitle)
        InfoRow("Reference", card.number); InfoRow("Category", card.kind)
        Spacer(Modifier.weight(1f))
        Button(onClick = onEdit, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit pass")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF7777))) {
            Icon(Icons.Default.DeleteOutline, null); Spacer(Modifier.width(8.dp)); Text("Delete pass")
        }
        Spacer(Modifier.height(20.dp))
        Disclaimer()
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = muted, fontSize = 14.sp)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
    HorizontalDivider(color = Color.White.copy(alpha = .08f))
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

@Composable
fun CardEditor(initial: WalletCard?, onCancel: () -> Unit, onSave: (WalletCard) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var subtitle by remember { mutableStateOf(initial?.subtitle ?: "Fictional pass") }
    var number by remember { mutableStateOf(initial?.number ?: "0000 0000 0000") }
    var kind by remember { mutableStateOf(initial?.kind ?: "Membership") }
    var image by remember { mutableStateOf(initial?.image ?: "") }
    var tint by remember { mutableLongStateOf(initial?.tint ?: 0xFF263A56) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            image = uri.toString()
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        TopBar(if (initial == null) "Add a pass" else "Edit pass", onCancel)
        Text("PREVIEW", color = muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        WalletPass(WalletCard(initial?.id ?: "new", title.ifBlank { "Your pass" }, subtitle, number, image, tint, kind),
            Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        FieldLabel("Pass name")
        OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("e.g. Metro Club") })
        Spacer(Modifier.height(12.dp)); FieldLabel("Description")
        OutlinedTextField(subtitle, { subtitle = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp)); FieldLabel("Reference number")
        OutlinedTextField(number, { number = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp)); FieldLabel("Pass category")
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }) { Text(kind); Icon(Icons.Default.ExpandMore, null) }
            DropdownMenu(expanded, { expanded = false }) {
                listOf("Membership", "Event", "Transit", "Loyalty", "Access", "Other").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { kind = it; expanded = false })
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text(if (image.isBlank()) "Choose card artwork" else "Change card artwork")
        }
        Text("Choose any image from your device. It is used as decorative artwork only.", color = muted, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp)); FieldLabel("Card colour")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(0xFF263A56, 0xFF4B285D, 0xFF1D594D, 0xFF7A4828, 0xFF343943, 0xFF6A2637).forEach { c ->
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (tint == c) 3.dp else 0.dp, Color.White, CircleShape)
                    .clickable { tint = c })
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            if (title.isNotBlank()) onSave(WalletCard(
                id = initial?.id ?: UUID.randomUUID().toString(), title = title.trim(),
                subtitle = subtitle.trim(), number = number.trim(), image = image, tint = tint, kind = kind
            ))
        }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("Save pass")
        }
        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        Disclaimer()
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun FieldLabel(text: String) {
    Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
}

@Composable
fun Disclaimer() {
    Text("SIMULATOR ONLY • NOT A PAYMENT CARD • NO NFC / PAYMENT / ID VALIDATION",
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        color = Color(0xFF777D89), fontSize = 9.sp, letterSpacing = .7.sp,
        textAlign = TextAlign.Center, lineHeight = 14.sp)
}

private fun saveCards(context: Context, cards: List<WalletCard>) {
    val array = JSONArray()
    cards.forEach { c ->
        array.put(JSONObject().put("id", c.id).put("title", c.title).put("subtitle", c.subtitle)
            .put("number", c.number).put("image", c.image).put("tint", c.tint).put("kind", c.kind))
    }
    context.getSharedPreferences("wallet_larp", Context.MODE_PRIVATE).edit().putString("cards", array.toString()).apply()
}
private fun loadCards(context: Context): List<WalletCard> = runCatching {
    val raw = context.getSharedPreferences("wallet_larp", Context.MODE_PRIVATE).getString("cards", null) ?: return emptyList()
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i)
        WalletCard(o.getString("id"), o.getString("title"), o.optString("subtitle"),
            o.optString("number"), o.optString("image"), o.optLong("tint", 0xFF263A56), o.optString("kind", "Membership"))
    }
}.getOrDefault(emptyList())
