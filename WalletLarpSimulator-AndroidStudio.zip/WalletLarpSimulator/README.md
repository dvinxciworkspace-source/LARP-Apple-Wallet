# Wallet LARP Simulator

A native Android app built with Kotlin and Jetpack Compose. This is a fictional prop/pass organizer for live-action roleplay (LARP), not a payment product.

## Included
- Dark, Wallet-inspired pass collection screen
- Add, edit, and delete fictional passes
- Choose any image from device storage as card artwork
- Editable title, description, reference number, category, and card colour
- Pass preview updates while editing
- Local persistence using app-private SharedPreferences
- Compose screen transitions and touch feedback
- Persistent SIMULATOR / NOT A PAYMENT CARD disclaimer

## Build
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Android SDK and Gradle installed):
```bash
gradle assembleDebug
```

Minimum Android version: Android 8.0 (API 26). Target SDK: 35.

## Notes
- The app does not implement NFC, payment processing, real card provisioning, QR/barcode credential validation, or identity verification.
- Pass artwork is decorative and remains clearly marked as fictional simulator content.
- No Apple trademarks, logos, or payment network assets are bundled.
